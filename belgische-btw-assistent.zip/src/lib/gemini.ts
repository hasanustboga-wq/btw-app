import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_INSTRUCTION = `Je bent een senior fiscaal expert en AI-assistent, gespecialiseerd in de Belgische btw-wetgeving. Jouw taak is om facturen (zowel aankoop als verkoop) te analyseren en exact te vertellen in welke roosters van de Belgische btw-aangifte de bedragen thuishoren.

PRIORITEITSREGEL: GEBRUIKERSINPUT OVERSCHRIJFT ALLES
De gebruiker zal bij het uploaden van de factuur specifieke parameters meesturen (bijvoorbeeld via de tekst: "Type is Aankoop" of "Type is Verkoop"). Jij moet deze instructies BLINDELINGS volgen.

1. Type Factuur (Aankoop vs. Verkoop):
- ALS de gebruiker aangeeft dat het een "Aankoop" of "Inkomend" is: Behandel het document 100% zeker als een inkomende factuur (aankoop/kost). Gebruik de roosters voor inkomende handelingen (81, 82, 83, 59, etc.), ZELFS ALS de lay-out of de namen op de factuur jou in de war brengen.
- ALS de gebruiker aangeeft dat het een "Verkoop" of "Uitgaand" is: Behandel het document 100% zeker als een uitgaande factuur (verkoop). Gebruik de roosters voor uitgaande handelingen (01, 02, 03, 54, etc.).
- Let op Creditnota's: Als het document duidelijk een "Creditnota" is of negatieve bedragen bevat, volg dan nog steeds de aankoop/verkoop keuze van de gebruiker, maar gebruik de specifieke creditnota-roosters (bijv. 84/63 voor een aankoop-creditnota).

2. Aftrekpercentage (Enkel bij Aankopen):
- De gebruiker stuurt een percentage mee (bijv. 100%, 50%, 0%). Gebruik EXACT dit percentage om de aftrekbare btw (rooster 59) te berekenen. Het overgebleven, niet-aftrekbare btw-bedrag tel je altijd op bij de maatstaf van heffing (de basis in rooster 81, 82 of 83).

JOUW OPDRACHT:
De gebruiker levert een factuur aan, een "aftrekpercentage", en optioneel een "Type Factuur". Jij extraheert de data, voert berekeningen uit, en classificeert de factuur voor de juiste roosters.

BESLISSINGSBOOM & REGELS:

STAP 1: Bepaal het type factuur (rekening houdend met de PRIORITEITSREGEL).
Is het een verkoopfactuur (Uitgaande handelingen) of een aankoopfactuur (Inkomende handelingen)? Of is het een creditnota?

STAP 2: Bepaal de roosters voor de Maatstaf van Heffing (Basisbedrag).
A. Voor UITGAANDE HANDELINGEN (Verkoop):
- 6% btw -> Rooster 01
- 12% btw -> Rooster 02
- 21% btw -> Rooster 03
- Btw verlegd door medecontractant -> Rooster 44 of 45 afhankelijk van diensten of werken.
- Vrijgesteld intracommunautair -> Rooster 46
- Uitgereikte creditnota's -> Rooster 48 (basis) en Rooster 64 (te recupereren btw).

B. Voor INKOMENDE HANDELINGEN (Aankoop):
Pas altijd de 'Niet-aftrekbare btw' logica toe! Bereken het aftrekbare deel van de btw via het opgegeven percentage. Tel de rest (verworpen btw) op bij de maatstaf van heffing (het exclusief bedrag).
Wijs deze verhoogde maatstaf van heffing toe aan:
- Handelsgoederen, grond- en hulpstoffen -> Rooster 81
- Diensten en diverse goederen -> Rooster 82 (Standaardkeuze indien onduidelijk)
- Bedrijfsmiddelen (Investeringen) -> Rooster 83
- Ontvangen creditnota's -> Rooster 84 (basis) en Rooster 63 (terug te storten btw).
- Intracommunautaire verwervingen -> Rooster 86

STAP 3: Bepaal de roosters voor de Btw-bedragen.
- VERSCHULDIGDE BELASTING: Btw op verkoop (roosters 01, 02, 03) komt in Rooster 54. Btw op intracommunautaire verwervingen (86) komt in 55.
- AFTREKBARE BELASTING: Het berekende aftrekbare deel van de aankoop-btw komt altijd in Rooster 59.

STAP 4: Geavanceerde Btw-regels (Verlegging van heffing & EU)
Let zeer goed op de volgende veelvoorkomende scenario's op inkomende facturen (aankopen):
- Btw Verlegd (Medecontractant / Art. 20): Staat er "Btw verlegd", "Medecontractant", "Autoliquidation" of "Art. 20" op de factuur? 
  -> De factuur zelf zal 0,00 EUR btw tonen. 
  -> JOUW TAAK: Bereken zelf fictief de Belgische btw (meestal 21%). Plaats dit berekende bedrag in Rooster 56 (Verschuldigd) én in Rooster 59 (Aftrekbaar, vermenigvuldigd met het aftrekpercentage). De maatstaf van heffing komt in 81/82/83 én moet ook in Rooster 87 gemeld worden.
- Intracommunautaire Verwerving (Aankoop uit de EU): Heeft de leverancier een buitenlands EU-btwnummer (bijv. NL, DE, FR) en staat er 0% btw (bijv. "Intra-Community supply")?
  -> JOUW TAAK: Bereken zelf fictief de Belgische btw. Plaats dit in Rooster 55 (Verschuldigd) én Rooster 59 (Aftrekbaar, volgens percentage). De maatstaf van heffing komt in 81/82/83 én moet in Rooster 86.

STAP 5: Fiscale Validatie (Compliance Check)
Controleer of de factuur voldoet aan de Belgische wettelijke eisen. 
- Staan alle verplichte velden erop? (Factuurdatum, uniek factuurnummer, naam+adres leverancier, en JOUW naam/btw-nummer).
- Advies over aftrekbaarheid: De gebruiker geeft een aftrekpercentage mee, maar jij bent de expert. Als de factuur duidelijk over restaurantkosten gaat (fiscaal 0% aftrekbaar voor de btw) of personenwagens (maximaal 50% aftrekbaar), en de gebruiker vult "100%" in, geef dan een strenge waarschuwing!

OUTPUT FORMAAT (JSON):
Beantwoord ALTIJD met deze exacte JSON structuur. Als een rooster niet van toepassing is, vul dan 0.00 in.`;

export interface AnalysisResult {
  document_info: {
    type: string;
    leverancier_of_klant: string;
    datum: string;
  };
  gegeven_aftrekpercentage: number;
  berekeningen: {
    totaal_excl_btw: number;
    totaal_btw: number;
    aftrekbare_btw: number;
    niet_aftrekbare_btw: number;
    maatstaf_van_heffing_voor_aangifte: number;
  };
  btw_aangifte_roosters: {
    uitgaande_handelingen_basis: Record<string, number>;
    inkomende_handelingen_basis: Record<string, number>;
    verschuldigde_belasting: Record<string, number>;
    aftrekbare_belasting: Record<string, number>;
  };
  geavanceerde_regels: {
    is_medecontractant_of_btw_verlegd: boolean;
    is_intracommunautaire_verwerving: boolean;
    rooster_86_bedrag: number;
    rooster_87_bedrag: number;
    rooster_55_berekend: number;
    rooster_56_berekend: number;
  };
  compliance_en_waarschuwingen: {
    is_factuur_wettelijk_geldig: boolean;
    ontbrekende_verplichte_velden: string[];
    fiscale_waarschuwing_aftrekbaarheid: string;
  };
  ai_verantwoording: string;
}

export async function analyzeInvoice(
  content: { fileBase64?: string; mimeType?: string; text?: string },
  deductionPercentage: number,
  invoiceType: string
): Promise<AnalysisResult> {
  const parts: any[] = [];
  
  if (content.fileBase64 && content.mimeType) {
    parts.push({
      inlineData: {
        data: content.fileBase64,
        mimeType: content.mimeType,
      },
    });
  }
  
  if (content.text) {
    parts.push({ text: content.text });
  }
  
  parts.push({ text: `Aftrekpercentage: ${deductionPercentage}%` });
  if (invoiceType !== 'Automatisch') {
    parts.push({ text: `Type is ${invoiceType}` });
  }

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: parts,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          document_info: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING },
              leverancier_of_klant: { type: Type.STRING },
              datum: { type: Type.STRING },
            },
          },
          gegeven_aftrekpercentage: { type: Type.NUMBER },
          berekeningen: {
            type: Type.OBJECT,
            properties: {
              totaal_excl_btw: { type: Type.NUMBER },
              totaal_btw: { type: Type.NUMBER },
              aftrekbare_btw: { type: Type.NUMBER },
              niet_aftrekbare_btw: { type: Type.NUMBER },
              maatstaf_van_heffing_voor_aangifte: { type: Type.NUMBER },
            },
          },
          btw_aangifte_roosters: {
            type: Type.OBJECT,
            properties: {
              uitgaande_handelingen_basis: {
                type: Type.OBJECT,
                properties: {
                  "01": { type: Type.NUMBER },
                  "02": { type: Type.NUMBER },
                  "03": { type: Type.NUMBER },
                  "44": { type: Type.NUMBER },
                  "48": { type: Type.NUMBER },
                },
              },
              inkomende_handelingen_basis: {
                type: Type.OBJECT,
                properties: {
                  "81": { type: Type.NUMBER },
                  "82": { type: Type.NUMBER },
                  "83": { type: Type.NUMBER },
                  "84": { type: Type.NUMBER },
                  "86": { type: Type.NUMBER },
                  "87": { type: Type.NUMBER },
                },
              },
              verschuldigde_belasting: {
                type: Type.OBJECT,
                properties: {
                  "54": { type: Type.NUMBER },
                  "55": { type: Type.NUMBER },
                  "56": { type: Type.NUMBER },
                  "63": { type: Type.NUMBER },
                },
              },
              aftrekbare_belasting: {
                type: Type.OBJECT,
                properties: {
                  "59": { type: Type.NUMBER },
                  "64": { type: Type.NUMBER },
                },
              },
            },
          },
          geavanceerde_regels: {
            type: Type.OBJECT,
            properties: {
              is_medecontractant_of_btw_verlegd: { type: Type.BOOLEAN },
              is_intracommunautaire_verwerving: { type: Type.BOOLEAN },
              rooster_86_bedrag: { type: Type.NUMBER },
              rooster_87_bedrag: { type: Type.NUMBER },
              rooster_55_berekend: { type: Type.NUMBER },
              rooster_56_berekend: { type: Type.NUMBER },
            },
          },
          compliance_en_waarschuwingen: {
            type: Type.OBJECT,
            properties: {
              is_factuur_wettelijk_geldig: { type: Type.BOOLEAN },
              ontbrekende_verplichte_velden: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              fiscale_waarschuwing_aftrekbaarheid: { type: Type.STRING },
            },
          },
          ai_verantwoording: { type: Type.STRING },
        },
      },
    },
  });

  if (!response.text) {
    throw new Error("No response from Gemini");
  }

  return JSON.parse(response.text) as AnalysisResult;
}
